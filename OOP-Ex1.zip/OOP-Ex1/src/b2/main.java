package b2;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ManageDocument md=new ManageDocument();
		
		while(true) {
			System.out.println("Application Manager Document");
            System.out.println("Enter 1: To insert document");
            System.out.println("Enter 2: To search document by category: ");
            System.out.println("Enter 3: To show information documents");
            System.out.println("Enter 4: To remove document by id");
            System.out.println("Enter 5: To exit:");
            String line=sc.nextLine();
            switch(line) {
            	case "1" :
            		System.out.println("Enter a: to insert Book");
                    System.out.println("Enter b: to insert Newspaper");
                    System.out.println("Enter c: to insert Journal");
                    String type = sc.nextLine();
                    switch (type) {
                    	case "a":{
                    		System.out.print("Enter ID: ");
                            String id = sc.nextLine();
                            System.out.print("Enter nxb:");
                            String nxb = sc.nextLine();
                            System.out.print("Enter number: ");
                            int number = sc.nextInt();
                            System.out.print("Enter author: ");
                            sc.nextLine();
                            String author = sc.nextLine();
                            System.out.print("Enter page number: ");
                            int pageNumber = sc.nextInt();
                            Document book = new Book(id, nxb, number, author, pageNumber);
                            md.addDocument(book);
                            System.out.println(book.toString());
                            sc.nextLine();
                            break;
                    	}
                    	case "b": {
                            System.out.print("Enter ID: ");
                            String id = sc.nextLine();
                            System.out.print("Enter nxb:");
                            String nxb = sc.nextLine();
                            System.out.print("Enter number: ");
                            int number = sc.nextInt();
                            System.out.print("Enter Day issue: ");
                            int dayIssue = sc.nextInt();
                            Document newspaper = new Newspaper(id, nxb, number, dayIssue);
                            md.addDocument(newspaper);
                            System.out.println(newspaper.toString());
                            sc.nextLine();
                            break;
                        }
                        case "c": {
                            System.out.print("Enter ID: ");
                            String id = sc.nextLine();
                            System.out.print("Enter nxb:");
                            String nxb = sc.nextLine();
                            System.out.print("Enter number: ");
                            int number = sc.nextInt();
                            System.out.print("Enter issue number : ");
                            int issueNumber = sc.nextInt();
                            System.out.print("Enter issue month : ");
                            int issueMonth = sc.nextInt();
                            Document journal = new Journal(id, nxb, number, issueNumber, issueMonth);
                            md.addDocument(journal);
                            System.out.println(journal.toString());
                            sc.nextLine();
                            break;
                        }
                        default:
                            break;
                    }
                    break;

				case "2": {
		            System.out.println("Enter a to search book");
		            System.out.println("Enter b to search newspaper");
		            System.out.println("Enter a to search journal");
		            String choise = sc.nextLine();
		            switch (choise) {
		                case "a": {
		                    md.searchByBook();
		                    break;
		                }
		                case "b": {
		                    md.searchByNewSpaper();
		                    break;
		                }
		                case "c":
		                    md.searchByJournal();
		                    break;
		                default:
		                    System.out.println("Invalid");
		                    break;
		            }
		            break;
		        }
		        case "3": {
		            md.showInfoDocument();
		            break;
		        }
		        case "4": {
		            System.out.print("Enter id to remove: ");
		            String id = sc.nextLine();
		            System.out.println(md.deleteDocument(id) ? "Success" : "Fail");
		        }
		        break;
		        case "5": {
		            return;
		        }
		        default:
		            System.out.println("Invalid");
		            continue;
			}
		}

	}
}
