package b2;

import java.util.ArrayList;
import java.util.List;

public class ManageDocument {
	List<Document> docs;
	
	ManageDocument(){
		this.docs=new ArrayList<>();
	}
	
	public void addDocument(Document doc) {
		this.docs.add(doc);
	}
	
	public boolean deleteDocument(String id) {
		Document doc=this.docs.stream().filter(d->d.getId().equals(id)).findFirst().orElse(null);
		if(doc==null) {
			return false;
		}
		docs.remove(doc);
		return true;
	}
	
	public void showInfoDocument() {
		this.docs.forEach(d->System.out.println(d.toString()));
	}
	
	public void searchByBook() {
		this.docs.stream().filter(d-> d instanceof Book).forEach(d->System.out.println(d.toString()));
	}
	
	public void searchByJournal() {
		this.docs.stream().filter(d-> d instanceof Journal).forEach(d->System.out.println(d.toString()));
	}
	
	public void searchByNewSpaper() {
		this.docs.stream().filter(d-> d instanceof Newspaper).forEach(d->System.out.println(d.toString()));
	}
}
