package b3;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		ManageCandidate mc = new ManageCandidate();
		
		while(true) {
			System.out.println("Application Manage Candidate");
			System.out.println("Enter 1: input candidate");
			System.out.println("Enter 2: show candidate");
			System.out.println("Enter 3: search candidate");
			System.out.println("Enter 4: cancel candidate");
			
			String line=sc.nextLine();
			
			switch(line) {
				case "1":{
					System.out.println("Enter a: input candidate a");
					System.out.println("Enter b: input candidate b");
					System.out.println("Enter c: input candidate c");
					String type=sc.nextLine();
					switch(type) {
						case "a": {
	                        mc.addCandidate(createCadidate(sc, "a"));
	                        //System.out.println(mc);
	                        break;
	
	                    }
	                    case "b": {
	                        mc.addCandidate(createCadidate(sc, "b"));
	                        break;
	                    }
	                    case "c": {
	                        mc.addCandidate(createCadidate(sc, "c"));
	                        break;
	                    }
	                    default:
	                        System.out.println("Invalid");
	                        break;
	
								
						}
					 break;
				}
				case "2":{
					mc.showInfoCandidate();
					break;
				}
				case "3":{
					System.out.println("Nhap id de tim kiem:");
					String id=sc.nextLine();
					Candidate cd=mc.searchById(id);
					if(cd==null) {
						System.out.println("Not found");
					}
					else {
						System.out.println(cd.toString());
					}
					break;
				}
				case "4":{
					return;
				}
				
				default:{
					System.out.println("Invalid");
                    continue;

				}
			
			}
	}
		
		
}
	
	public static Candidate createCadidate(Scanner scanner, String cate) {
        System.out.print("Enter ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter address: ");
        String address = scanner.nextLine();
        System.out.print("Enter Priotity: ");
        int priority = scanner.nextInt();
        scanner.nextLine();
        if (cate.equals("a")) {
            return new CandidateA(id, name,address,priority);
        } else if (cate.equals("b")) {
            return new CandidateB(id, name,address,priority);
        } else {
            return new CandidateC(id, name,address,priority);
        }
        
    }


}
