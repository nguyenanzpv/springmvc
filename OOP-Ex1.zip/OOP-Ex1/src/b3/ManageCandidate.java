package b3;

import java.util.ArrayList;
import java.util.List;

public class ManageCandidate {
	List<Candidate> cans;

	public ManageCandidate() {
		this.cans = new ArrayList<>();
	}
	
	public void addCandidate(Candidate can) {
		this.cans.add(can);
	}
	
	public void showInfoCandidate() {
		this.cans.forEach(c->System.out.println(c.toString()));
	}
	
	public Candidate searchById(String id) {
		return this.cans.stream().filter(c->c.getId().equals(id)).findFirst().orElse(null);
	}
}
