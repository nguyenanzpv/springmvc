package b8;

public class Student {

}
