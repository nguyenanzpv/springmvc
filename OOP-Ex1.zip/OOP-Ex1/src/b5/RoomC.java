package b5;

public class RoomC extends Room {

	public RoomC() {
		super("C", 100);
		// TODO Auto-generated constructor stub
	}

	@Override()
	public String toString() {
		return "RoomC{" +
                "category='" + category + '\'' +
                ", price=" + price +
                '}';

	}
}
