package b5;

import java.util.ArrayList;
import java.util.List;

public class Hotel {
	List<Person> persons;

	public Hotel() {
		super();
		this.persons = new ArrayList<>();
	}
	
	public void add(Person person) {
		this.persons.add(person);
	}
	
	public boolean deleteByPassport(String passport) {
		Person p=this.persons.stream().filter(o->o.getPassport().equals(passport)).findFirst().orElse(null);
		if(p==null) {
			return false;
		}else {
			this.persons.remove(p);
			return true;
		}
		
	}
	
	public int calculator(String passport) {
		Person p=this.persons.stream().filter(o->o.getPassport().equals(passport)).findFirst().orElse(null);
		if(p==null) {
			return 0;
		}
		else {
			return p.getNumberRent()* p.getRoom().getPrice();
		}
	}
	
	public void show() {
		this.persons.forEach(o->System.out.println(o.toString()));
	}
	
	
}
