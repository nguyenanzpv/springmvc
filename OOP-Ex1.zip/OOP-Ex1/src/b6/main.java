package b6;

import java.util.Scanner;

public class main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		School s=new School();
		
		 while (true) {
	            System.out.println("Application Manager Candidate");
	            System.out.println("Enter 1: To insert person for rent");
	            System.out.println("Enter 2: To remove person by passport");
	            System.out.println("Enter 3: To calculator price by passport");
	            System.out.println("Enter 4: To show infor");
	            System.out.println("Enter 5: To exit:");
	            String line = sc.nextLine();
	            
	            switch(line) {
	            	
	            }
		 
	            s.showInfoStudent20();

	            s.showinfoStuden23();
		}

	}
}
