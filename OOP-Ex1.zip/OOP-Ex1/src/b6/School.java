package b6;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class School {
	List<Student> students;
	
	School(){
		this.students=new ArrayList<>();
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}
	
	public void add(Student s) {
		this.students.add(s);
	}
	
	public List<Student> showInfoStudent20(){
		return this.students.stream().filter(s->s.getAge()==20).collect(Collectors.toList());
	}
	
	public List<Student> showinfoStuden23(){
		return this.students.stream().filter(s->s.getAge()==23 && s.getHometown().equals("DN")).collect(Collectors.toList());
	}
}
