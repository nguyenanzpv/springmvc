import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ManageOfice {
	List<Office> offices;

	public ManageOfice() {
		offices= new ArrayList<>();
	}
	
	public void addOffice(Office office) {
		this.offices.add(office);
	}
	
	public List<Office> searchByName(String name) {
		return offices.stream().filter(o->o.getName().contains(name)).collect(Collectors.toList());
	}
	
	public void showListInfoOffice() {
		this.offices.forEach(o->System.out.println(o));
	}
	
}
