package b4;

import java.util.ArrayList;
import java.util.List;

public class Town {
	private List<Family> families;

	public Town() {
		super();
		this.families = new ArrayList<>();
	}

	public List<Family> getFamilies() {
		return families;
	}

	public void setFamilies(List<Family> families) {
		this.families = families;
	}
	
	public void addFamily(Family family) {
        this.families.add(family);
    }
	
	public void showInfoTown() {
        this.families.forEach(t->System.out.println(t.toString()));
    }

	
}
