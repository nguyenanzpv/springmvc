package b4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class main {
	public static void main(String[] args) {
		Town town=new Town();
		Scanner sc=new Scanner(System.in);
		List<Person> persons=new ArrayList<>();
		System.out.println("Enter n:");
		int n=sc.nextInt();
		sc.nextLine();
		
		for(int i=0;i<n;i++) {
			System.out.println("Enter address:");
			//sc.nextLine();
			String address=sc.nextLine();
			
			
			System.out.println("Enter number persons:");
			int m=sc.nextInt();
			sc.nextLine();
			for(int j=0;j<m;j++) {
				System.out.println("Enter name:");
				//sc.nextLine();
				String name=sc.nextLine();
				System.out.println("Enter age:");				
				int age=sc.nextInt();
				sc.nextLine();
				System.out.println("Enter job:");
				//sc.nextLine();
				String job=sc.nextLine();
				System.out.println("Enetr passport:");
				String passport=sc.nextLine();
				
				persons.add(new Person(name,age,job,passport));
			}
			System.out.println(persons.get(0));
			town.addFamily(new Family(persons,address));
		}
		
		town.showInfoTown();
	}
}
